"""
AmboTsavo Schools API
Security-first Flask + SQLite foundation. Set SECRET_KEY and bootstrap credentials in environment.
Never use demo/default credentials in production.
"""
import os
import secrets
from datetime import timedelta
from functools import wraps

from dotenv import load_dotenv
from flask import Flask, jsonify, request, session, send_from_directory
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

load_dotenv()
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DIST_DIR = os.path.join(BASE_DIR, "dist")
app = Flask(__name__, static_folder=DIST_DIR, static_url_path="")
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
    SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///" + os.path.join(BASE_DIR, "ambotsavo.db")).replace("postgres://", "postgresql://", 1),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "true").lower() == "true",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)
db = SQLAlchemy(app)
limiter = Limiter(get_remote_address, app=app, default_limits=["300 per hour"])

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin, teacher, parent
    active = db.Column(db.Boolean, default=True, nullable=False)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_reg_no = db.Column(db.String(80), unique=True, nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    grade = db.Column(db.String(40), nullable=False)
    campus = db.Column(db.String(100), nullable=False)
    parent_name = db.Column(db.String(160), nullable=True)
    status = db.Column(db.String(30), default="Active", nullable=False)

class Teacher(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    staff_code = db.Column(db.String(80), unique=True, nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    email = db.Column(db.String(254), unique=True, nullable=True)
    grade_assigned = db.Column(db.String(40), nullable=False)
    campus = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True, nullable=True)

class Announcement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    campus = db.Column(db.String(100), default="All Campuses", nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now(), nullable=False)

class FeeStructure(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    grade = db.Column(db.String(40), unique=True, nullable=False)
    tuition = db.Column(db.Integer, nullable=False, default=0)
    lunch_and_snacks = db.Column(db.Integer, nullable=False, default=0)
    activity_and_craft = db.Column(db.Integer, nullable=False, default=0)
    swimming_and_co_curricular = db.Column(db.Integer, nullable=False, default=0)
    total_term_fee = db.Column(db.Integer, nullable=False, default=0)

def current_user():
    user_id = session.get("user_id")
    return db.session.get(User, user_id) if user_id else None

def login_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            user = current_user()
            if not user or not user.active:
                return jsonify(error="Authentication required"), 401
            if roles and user.role not in roles:
                return jsonify(error="You do not have permission to do that"), 403
            return fn(*args, **kwargs)
        return wrapped
    return decorator

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; connect-src 'self'"
    if request.is_secure:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Cache-Control"] = "no-store" if request.path.startswith("/api/") else response.headers.get("Cache-Control", "public, max-age=300")
    return response

@app.before_request
def require_json_for_mutations():
    if request.path.startswith("/api/") and request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        if request.method != "DELETE" and not request.is_json:
            return jsonify(error="Send a JSON request body"), 415
        # Same-origin browser request protection. API clients should send this header too.
        origin = request.headers.get("Origin")
        if origin and origin.rstrip("/") != request.host_url.rstrip("/"):
            return jsonify(error="Cross-origin request blocked"), 403

@app.get("/api/health")
@limiter.limit("60 per minute")
def health():
    return jsonify(status="ok", service="ambotsavo-api", database="sqlite-or-configured-sql")

@app.post("/api/auth/login")
@limiter.limit("5 per minute")
def login():
    body = request.get_json(silent=True) or {}
    username = str(body.get("username", "")).strip().lower()
    password = str(body.get("password", ""))
    if not username or not password or len(username) > 120 or len(password) > 1024:
        return jsonify(error="Enter a valid username and password"), 400
    user = User.query.filter(db.func.lower(User.username) == username).first()
    if not user or not user.active or not check_password_hash(user.password_hash, password):
        return jsonify(error="Invalid credentials"), 401
    session.clear()
    session["user_id"] = user.id
    session.permanent = True
    return jsonify(user={"username": user.username, "role": user.role})

@app.post("/api/auth/logout")
@login_required()
def logout():
    session.clear()
    return jsonify(status="signed_out")

@app.get("/api/auth/me")
def me():
    user = current_user()
    if not user or not user.active:
        return jsonify(user=None), 200
    return jsonify(user={"username": user.username, "role": user.role})

@app.get("/api/students")
@login_required("admin", "teacher")
def list_students():
    query = Student.query.order_by(Student.name.asc())
    user = current_user()
    # For production, associate teacher users with a Teacher row and filter by assigned campus/grade.
    if user.role == "teacher":
        teacher = Teacher.query.filter_by(user_id=user.id).first()
        if not teacher:
            return jsonify(students=[]), 200
        query = query.filter_by(grade=teacher.grade_assigned, campus=teacher.campus)
    return jsonify(students=[{"id": x.id, "studentRegNo": x.student_reg_no, "name": x.name, "grade": x.grade, "campus": x.campus, "parentName": x.parent_name, "status": x.status} for x in query.all()])

@app.post("/api/students")
@login_required("admin")
def create_student():
    body = request.get_json(silent=True) or {}
    required = ["studentRegNo", "name", "grade", "campus"]
    if any(not str(body.get(k, "")).strip() for k in required):
        return jsonify(error="studentRegNo, name, grade and campus are required"), 400
    if len(str(body["name"])) > 160 or len(str(body["studentRegNo"])) > 80:
        return jsonify(error="One or more fields are too long"), 400
    row = Student(student_reg_no=str(body["studentRegNo"]).strip(), name=str(body["name"]).strip(),
                  grade=str(body["grade"]).strip(), campus=str(body["campus"]).strip(),
                  parent_name=str(body.get("parentName", "")).strip()[:160] or None,
                  status=str(body.get("status", "Active"))[:30])
    db.session.add(row)
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify(error="Could not create student; registration number may already exist"), 409
    return jsonify(id=row.id, status="created"), 201

@app.get("/api/teachers")
@login_required("admin")
def list_teachers():
    return jsonify(teachers=[{"id": x.id, "staffCode": x.staff_code, "name": x.name, "email": x.email, "gradeAssigned": x.grade_assigned, "campus": x.campus} for x in Teacher.query.order_by(Teacher.name.asc()).all()])

@app.get("/api/announcements")
def list_announcements():
    return jsonify(announcements=[{"id": x.id, "title": x.title, "content": x.content, "campus": x.campus, "createdAt": x.created_at.isoformat() if x.created_at else None} for x in Announcement.query.order_by(Announcement.created_at.desc()).limit(100).all()])

@app.post("/api/announcements")
@login_required("admin", "teacher")
def create_announcement():
    body = request.get_json(silent=True) or {}
    title, content = str(body.get("title", "")).strip(), str(body.get("content", "")).strip()
    if not title or not content or len(title) > 200 or len(content) > 10000:
        return jsonify(error="A title and content are required (maximum 10,000 characters)"), 400
    row = Announcement(title=title, content=content, campus=str(body.get("campus", "All Campuses"))[:100])
    db.session.add(row)
    db.session.commit()
    return jsonify(id=row.id, status="created"), 201

@app.get("/api/fees")
@login_required("admin", "teacher")
def list_fees():
    return jsonify(fees=[{"grade": x.grade, "tuition": x.tuition, "lunchAndSnacks": x.lunch_and_snacks, "activityAndCraft": x.activity_and_craft, "swimmingAndCoCurricular": x.swimming_and_co_curricular, "totalTermFee": x.total_term_fee} for x in FeeStructure.query.order_by(FeeStructure.grade.asc()).all()])

@app.errorhandler(429)
def rate_limited(_):
    return jsonify(error="Too many requests. Please wait and try again."), 429

@app.errorhandler(413)
def request_too_large(_):
    return jsonify(error="Request body is too large"), 413

def page_for_host():
    host = request.host.split(":", 1)[0].lower()
    if host == os.environ.get("ADMIN_HOST", "").strip().lower() and os.environ.get("ADMIN_HOST"):
        return "admin.html"
    if host == os.environ.get("TEACHER_HOST", "").strip().lower() and os.environ.get("TEACHER_HOST"):
        return "teachers.html"
    return "index.html"

@app.get("/")
def index():
    if os.path.isdir(DIST_DIR):
        return send_from_directory(DIST_DIR, page_for_host())
    return jsonify(service="AmboTsavo API", message="Build the frontend with npm run build.")

@app.get("/<path:path>")
def frontend(path):
    if path.startswith("api/"):
        return jsonify(error="Not found"), 404
    if os.path.isdir(DIST_DIR):
        candidate = os.path.join(DIST_DIR, path)
        if os.path.isfile(candidate):
            return send_from_directory(DIST_DIR, path)
    return jsonify(error="Not found"), 404

def bootstrap_admin():
    username = os.environ.get("BOOTSTRAP_ADMIN_USERNAME", "").strip().lower()
    password = os.environ.get("BOOTSTRAP_ADMIN_PASSWORD", "")
    if username and password and not User.query.filter_by(username=username).first():
        if len(password) < 14:
            raise RuntimeError("BOOTSTRAP_ADMIN_PASSWORD must be at least 14 characters.")
        db.session.add(User(username=username, password_hash=generate_password_hash(password), role="admin"))
        db.session.commit()

with app.app_context():
    db.create_all()
    bootstrap_admin()

if __name__ == "__main__":
    # Production deployments should run gunicorn server:app, not Flask's debug server.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
