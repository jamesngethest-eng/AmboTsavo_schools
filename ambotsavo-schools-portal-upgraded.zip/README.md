# AmboTsavo Schools Portal — hardened upgrade

This upgrade keeps the existing school website copy, campus information, fee values, imagery, and React portals. It adds a dedicated `teachers.html` entry point, keeps `admin.html` as a separate entry point, and adds a Python Flask API with SQLAlchemy database models, secure password hashing, session cookies, role checks, security headers, request-size limits, and rate limiting.

## Local development

Requirements: Node.js 20+ and Python 3.11+.

```bash
npm ci
npm run dev
```

The Vite development server serves:
- `/` — public school website
- `/admin.html` — admin portal page
- `/teachers.html` — teacher portal page

Run the API separately in another terminal:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python server.py
```

API listens on port 5000. `GET /api/health` is a health check. In production, use Gunicorn as in `render.yaml`.

## Database

The API uses SQLAlchemy and SQLite locally (`ambotsavo.db`). For live school records, use a managed PostgreSQL database and set `DATABASE_URL` in the hosting dashboard. Do not rely on a hosting provider's temporary filesystem for SQLite persistence.

Tables currently defined: users, students, teachers, announcements, and fee structures. API endpoints include `/api/auth/login`, `/api/auth/logout`, `/api/auth/me`, `/api/students`, `/api/teachers`, `/api/announcements`, and `/api/fees`. Mutating student records is admin-only; student listing is limited to admins/teachers; announcements require a signed-in admin or teacher to create.

## Hosting on Render

1. Push this project to a private Git repository.
2. Create a Render PostgreSQL database and copy its **internal connection string** into the web service's `DATABASE_URL`.
3. Add `BOOTSTRAP_ADMIN_USERNAME` and `BOOTSTRAP_ADMIN_PASSWORD` in Render Environment. Use a unique password with at least 14 characters. The admin account is created once when the service starts and the username does not already exist.
4. Set `SECRET_KEY` to a long random secret (Render can generate it), `COOKIE_SECURE=true`, and deploy using the included `render.yaml`.
5. After the first admin is created, remove or rotate bootstrap credentials from the environment. Never commit `.env`, database files, or credentials.

## Separate teacher and admin addresses

`admin.html` and `teachers.html` are separate built pages, accessible on the same deployment as `/admin.html` and `/teachers.html`.

To use true separate subdomains, attach two custom domains to the same Render service in the Render dashboard and configure DNS:
- `admin.YOUR-DOMAIN` → set `ADMIN_HOST` to that exact hostname
- `teachers.YOUR-DOMAIN` → set `TEACHER_HOST` to that exact hostname

When those hosts are configured, opening the root `/` on the admin hostname serves `admin.html`, and opening `/` on the teacher hostname serves `teachers.html`. You must own the domain and configure DNS/TLS; code alone cannot create or register domains.

## Important security and migration notes

- The security headers and API rate limits are defensive layers, not a full managed web application firewall (WAF). Consider Cloudflare or your host's WAF for edge filtering and DDoS mitigation.
- The original React portals still read/write application records through browser `localStorage`, and their existing PIN/teacher login flows are client-side. They have **not yet been fully migrated to these database-backed API endpoints**. A user can manipulate local browser data, and client-side PIN checks are not suitable protection for real student records. Do not put live student data online until all portal reads/writes and authentication are migrated to server-side API calls and tested.
- API password authentication is available through `/api/auth/login`, but the current React portal login forms are not wired to it yet. The API models are a secure migration foundation, not a claim that the legacy UI is already production-secure.
- The current API's teacher student list is restricted to the teacher's assigned grade and campus when a teacher account is linked to a Teacher row. Build teacher account provisioning and role assignment into the admin workflow before production.
- Back up the database, restrict admin accounts, use MFA where possible, and never store plain-text passwords or API keys in frontend files.

## Tests / build

```bash
npm run build
python -m py_compile server.py
```
